<?php
	include_once 'headermenu.php'; 
?>
<?php
		if (isset($_POST['search'])) {
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "online food ordering";


		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		$sfood=  $_POST['food'];
		$result =mysqli_query($conn,"call searchfood('$sfood')");
		$resultCheck = mysqli_num_rows($result);
		
		?><section class="main-container">
		<div class="main-wrapper">
			<h2>Search Results</h2><br>
		</div>
		</section><?php

		if($resultCheck>0)
		{
			
			
			while($row= $result->fetch_assoc())
			{
				?><center><table style="border: 2px solid #0c224c;font-style: italic;font-size: 20px">  <?php 
				$fdno=$row['foodno'];
				?> <tr> 
				<td style="border: 2px solid #0c224c" > <?php echo ""; ?> <img src="<?php echo $row["image"]; ?>" width=" 300" height="150"> <?php echo ""?> </td>  
				  <td style="border: 2px solid #0c224c ; ">  
						
					<ul style=" padding-left: 50px;padding-top: 100px ">
						<li>Name :<?php	echo $row["fname"];?></li>
						<li>Type :<?php	echo $row["type"];?></li>
						<li>Category :<?php	echo $row["category"];?></li>
						<li>Price :<?php	echo $row["price"];?></li>
						
					</ul>

					<?php

					 echo '<form class="signup-form" action="includes/order.inc.php" method="POST">
							<button type="submit" name="add" value=' .$fdno.'>ADD</button>	</form>';	
					?>
							
					</td> 

				</tr> 
				 </table></center><?php 
				
			}
		}
		else
		{
			echo '<div style="font-style:italic;font-size:30px;">';
			echo"<br><center>No Results Found </center>";
		}

		 echo '<form class="signup-form" action="menu.php" method="POST">
				<button type="submit" name="cart" >BACK</button></form>';
		
		
	}

?>		
<?php

	include_once 'footer.php';
?>