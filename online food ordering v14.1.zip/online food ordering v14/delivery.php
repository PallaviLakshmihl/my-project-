<?php
	include_once 'headerdelivery.php';
	if (isset($_SESSION['d_pid']))
	{
		?><center style="font-style: italic;font-size: 30px"><?php

		echo '<br><pre><form action="deliveryviews.php" method="POST">1. View delivery orders <button type="submit" name="1">View</button></form>';
		echo '<br><form action="deliveryviews.php" method="POST">2. View orders of the day <button type="submit" name="2">View</button></form>'; 
		echo '<br><form action="deliveryviews.php" method="POST">3. Update status of orders <input type = "text" name="orderno" placeholder="Enter orderno"> <button type="submit" name="3">View</button></form></pre>';

		?></center><?php
	}
?>
<?php
	include_once 'footer.php'; /*to include footer code here*/
?>