<?php
	include_once 'headermenu.php'; 
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "online food ordering";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
	//insert new order no into the order table of the present user
	//getting the user_id when menu was licked
	
	if (isset($_POST['menu'])) {
		$userid=$_POST['menu'];
		$sql1= "select max(orderno) as orderno from orders";
		$result1 = mysqli_query($conn,$sql1);
		$row1 = mysqli_fetch_assoc($result1);
		$ordno = $row1['orderno'];
		$ordno =$ordno+1;
		$sql2 = "insert into orders(orderno,user_id) values($ordno,$userid)";
		mysqli_query($conn,$sql2);

		$sql3="select max(orderno) as orderno from orders ";
		$result3=mysqli_query($conn,$sql3);
		$row = mysqli_fetch_assoc($result3);
		$orderno=$row['orderno'];

		$sql12= "select max(pid) as pid from payment";
		$result12 = mysqli_query($conn,$sql12);
		$row12 = mysqli_fetch_assoc($result12);
		$pid = $row12['pid'];
		$pid =$pid+1;
		$sql4 = "insert into payment(pid,orderno) values($pid,$orderno)";
		mysqli_query($conn,$sql4);
	}
	?><section class="main-container">
	<div class="main-wrapper">
		<h2>Menu</h2><br>
	</div>
	</section><?php
	/*$sql = "SELECT * from Product";
	$result = $conn->query($sql);*/
	function viewmenu($type1,$category1)
	{	
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "online food ordering";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		$sql = "call dispmenu('$type1','$category1')";
		$result9=$conn->prepare($sql);
		$res = $result9->execute();
		$r = $result9->get_result();
		
		?>
		
		
		<center><table style="border: 2px solid #0c224c;font-size:20px;color: black;">  <?php 

			while($row= $r->fetch_assoc())
			{
				$fdno=$row['foodno'];
				
				?> <tr> 
				<td style="border: 2px solid #0c224c" > <?php echo ""; ?> <img src="<?php echo $row["image"]; ?>" width=" 300" height="150"> <?php echo ""?> </td>  
				  <td style="border: 2px solid #0c224c ; ">  
						
					<ul style=" padding-left: 50px;padding-top: 100px ">
						<li>Name :<?php	echo $row["fname"];?></li>
						<li>Type :<?php	echo $row["type"];?></li>
						<li>Category :<?php	echo $row["category"];?></li>
						<li>Price :₹<?php	echo $row["price"];?></li>
						
					</ul>

					<?php
						echo '<form class="signup-form" action="includes/order.inc.php" method="POST">
							<button type="submit" name="add" value=' .$fdno.'>ADD</button>	</form>';
							
					?>
							
					</td> 

				</tr> <?php 
				
			}

		 	?> </table></center><?php 	


	}
	?><div style="text-align:center;font-size: 30px;color: green"><?php
	echo "<br><h1>VEG</h1><br>";
	echo "<em>Pasta<br>";
	echo "<br>";
	viewmenu('VEG',"Pasta");
	echo "<br>Starters<br>";
	echo "<br>";
	viewmenu("VEG","Starters");
	echo "<br>Breakfast<br>";
	echo "<br>";
	viewmenu("VEG","Breakfast");
	echo "<br>Main Course<br>";
	echo "<br>";
	viewmenu("VEG","Main Course");
	echo "</em><br><h1>NON VEG</h1><br>";
	echo "<em>Starters<br>";
	echo "<br>";
	viewmenu("NON VEG","Starters");
	echo "<br>Soups<br>";
	echo "<br>";
	viewmenu("NON VEG","Soups");
	echo "<br>Main Course<br>";
	echo "<br>";
	viewmenu("NON VEG","Main Course");
	?></em></div><?php
			 
	 echo '<form class="signup-form" action="order.php" method="POST">
					<button type="submit" name="cart" >ViewCart</button></form>';	
	echo "</br>";
	echo "</br>";
	echo "</br>";

?>
<?php

	include_once 'footer.php';
?>