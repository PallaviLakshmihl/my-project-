<?php
	include_once 'header.php'; 
	
?>
<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "online food ordering";


	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	if(isset($_POST['confirm']))
	{
		$orderno=$_POST['confirm'];
		$sql="select * from payment p,orders o where p.orderno=o.orderno and o.orderno='$orderno'";
		$result= $conn->query($sql);
		$row= $result->fetch_assoc();
		$totalamt=$row['amt'];
		$numberofitems=$row['numitems'];

		$date = date('Y-m-d');

		date_default_timezone_set("Asia/Calcutta");
		$time= date("H:i:s");

		$sql="update orders set orderdate='$date',ordertime='$time' where orderno='$orderno'";
		$conn->query($sql);
	}

	?><section class="main-container">
	<div class="main-wrapper">
		<h2>Confirmation</h2><br>
	</div>
	</section>
	<div style="font-style: italic;color: #0c244c;font-size: 40px;text-align: center;border: 2px solid black;background-color: white;padding-bottom: 20px; width: 35%;height:50%;margin-left:30.5% ;margin-top: 40px;padding:30px"><?php
	
	echo "Order Number   :   ".$orderno;
	echo "<br>";
	echo "Total number of items :  ".$numberofitems;
	echo "<br>";
	echo "Total amount  :  ".$totalamt;
	echo "<br>";
	echo "Mode  :  Cash on delivery</br>";
	$sql7="select * from delivery where noOfOrdersDelivered in (select min(noOfOrdersDelivered) from delivery)";
	$result7=$conn->query($sql7);
	$row=$result7->fetch_assoc();
	$deliveryname = $row['deliverypname'];
	$deliverypno=$row['deliverypphone'];
	$deliverypid=$row['deliverypid'];
	$noOfOrdersDelivered=$row['noOfOrdersDelivered'];
	$noOfOrdersDelivered=$noOfOrdersDelivered+1;

	$sql3="update delivery set noOfOrdersDelivered='$noOfOrdersDelivered' where deliverypid='$deliverypid'";
	mysqli_query($conn,$sql3);

	$sql="update orders set deliverypid='$deliverypid' where orderno='$orderno'";
	mysqli_query($conn,$sql);
	echo "</br>Delivery person details";echo "<br>";
	echo "Name : ".$deliveryname;
	echo "<br>";
	echo "Phone number : ".$deliverypno;
	echo '<br>';
	echo '<form class="signup-form" action="index.php" method="POST">
			<button type="submit" name="done" >DONE</button></form>';
	?></div>
	<?php


?>

<?php

	include_once 'footer.php';
?>	