<?php
	include_once 'header.php'; 
	
?>
<?php

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "online food ordering";


	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	$sql3="select max(orderno) as orderno from orders ";
	$result3=mysqli_query($conn,$sql3);
	$row = mysqli_fetch_assoc($result3);
	$orderno=$row['orderno'];
	$sql4="select p.*,c.quantity from product p,orders o,contains c where c.orderno = o.orderno and p.foodno=c.foodno and o.orderno='$orderno'";
	$result = $conn->query($sql4);
	$num=1;
	$totalprice=0;

	?><section class="main-container">
	<div class="main-wrapper">
		<h2>Cart</h2><br>
	</div>
	</section>
	<br>
	<br>
	<center>
		<table style="border: 2px solid black;align-content: center; width:50%; height:100%;">
			<tr style="background-color:  white">
					<td  style="border: 2px solid black;font-size:30px; padding: 20px;text-align: center;color: #0c244c;font-style: italic;">Item No</td>
					<td  style="border: 2px solid black;font-size:30px;padding: 20px;text-align: center;color: #0c244c;font-style: italic;">FoodName</td>
					<td  style="border: 2px solid black;font-size:30px;padding: 20px;text-align: center;color: #0c244c;font-style: italic;">Unit Price</td>
					<td  style="border: 2px solid black;font-size:30px;padding: 20px;text-align: center;color: #0c244c;font-style: italic;">Quantity</td>
					<td  style="border: 2px solid black;font-size:30px;padding: 20px;text-align: center;color: #0c244c;font-style: italic;">Modify</td>
			</tr>
		<?php
		while($row1= $result->fetch_assoc())
		{	
			$fdno=$row1['foodno'];
			$fname=$row1['fname'];
			$price=$row1['price'];
			$quantity=$row1['quantity'];
			?> 
			

				
				<tr  style="border: 2px solid black;background-color:  white">
					
					<td style="border: 2px solid  black">
					<div style="font-size:20px;text-align: center;color: #0c244c;font-style: italic;"><?php echo "$num";?></div>
					</td>
					<td  style="border:2px solid black">
						<div style="font-size: 20px;text-align: center;color: #0c244c;font-style: italic;"><?php echo "$fname"; ?></div>
					</td >

					<td  style="border:2px solid black ">
						<div style="font-size: 20px;text-align: center;color: #0c244c;font-style: italic;"><?php echo "₹$price"; ?></div>
					</td>
					<td  style="border:2px solid black ">
						<div style="font-size: 20px;text-align: center;color: #0c244c;font-style: italic;"><?php echo "$quantity"; ?></div>
					</td>
					
					<td  style="border:2px solid black ">
						<div style="font-size: 20px;text-align: center;color: #0c244c;font-style: italic;"><table><?php 
							
							echo '<td style="padding:10px"><form  action="includes/remove.inc.php" method="POST">
							<button type="submit" name="plus" value=' .$fdno.'>+</button></form></td>'; 
							if($quantity>1)
							{
								echo '<td style="padding:10px"><form action="includes/remove.inc.php" method="POST">
								<button type="submit" name="minus" value=' .$fdno.'>-</button> </form></td>';
							}	
							echo '<td style="padding:10px"><form  action="includes/remove.inc.php" method="POST">
							<button type="submit" name="remove" value=' .$fdno.'>REMOVE</button></form></td>'; 
							?></table></div>
					</td>


				</tr>
				
						<?php $num=$num+1;
							$totalprice=$totalprice+($price*$quantity); ?>
				 <?php
		}
		?>
		
		</table><br>
		<center style="font-size: 30px;text-align: center;color: #0c244c;font-style: italic;">TotalPrice=₹<?php echo "$totalprice";?></center>
	</center><br><br><br>
	<?php


		if($totalprice>0)
		{	
			?><center>
				<table>
					<tr>
						<th>
							<form class="signup-form" action="menu.php" method="POST">
							<button type="submit" name="cart" >Back</button></form>
						</th>
						<th>
							<?php echo '<form class="signup-form" action="confirm.php" method="POST">
							<button type="submit" name="confirm" value=' .$orderno. '>Confirm</button></form>';?>
						</th>

						<th>
							<?php echo'<form class="signup-form" action="includes/discard.inc.php" method="POST">
							<button type="submit" name="discard" value=' .$orderno. ' >Discard</button></form>';?>
						</th>
					</tr>
				</table>
			</center>
				<?php
			$totalitems=$num-1;
			/*$sql5="insert into payment(orderno,amt,numitems) values ($orderno,$totalprice,$totalitems)";
			mysqli_query($conn,$sql5);*/
		}
		else {
			$sql10="delete from orders where orderno='$orderno'";
			mysqli_query($conn,$sql10);
			
		}
		


	?>

<?php

	include_once 'footer.php';
?>	