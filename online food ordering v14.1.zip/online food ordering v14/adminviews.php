<?php
	include_once 'headeradmin.php';

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "online food ordering";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	function vieworders($date)
	{	
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "online food ordering";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		$sql="select * from orders where orderdate='$date'";
		$result=mysqli_query($conn,$sql);
		$resultCheck = mysqli_num_rows($result);

		?><center style="font-style: italic;font-size: 30px;"><?php

		if ($resultCheck<1)
		{
			echo "<br>No Orders";
		}
		else
		{
			?>
				<br><table  width="700px" height="150px" border="2px" cellpadding="20px" cellspacing="5px" style="background-color: white;text-align: center;">
					<tr >
						<th>Orderno</th>
						<th>Userid</th>
						<th>Delivery Person Id</th>
						<th>Delivery Status</th>
					</tr>
			<?php 
				
			while($row=$result->fetch_assoc())
			{
				$orderno=$row['orderno'];
				$userid=$row['user_id'];
				$deliverypid=$row['deliverypid'];
				$status=$row['status'];

				echo"<tr>
							<td>$orderno</td>
							<td>$userid</td>
							<td>$deliverypid</td>
							<td>$status</td>
					 </tr>";

			}
			?></table></center><?php
		}
	}

	if (isset($_POST['1'])) {
		$today = date('Y-m-d');
		?><section class="main-container">
		<div class="main-wrapper">
			<h2>Orders of the day</h2><br>
		</div>
		</section><?php
		vieworders($today);
		
	}

	elseif (isset($_POST['2']))
	{
		$particulardate=$_POST['date'];
		?><section class="main-container">
		<div class="main-wrapper">
			<h2>Orders of <?php echo "$particulardate";?></h2><br>
		</div>
		</section><?php
		vieworders($particulardate);
	}

	elseif (isset($_POST['3']))
	{
		?><section class="main-container">
		<div class="main-wrapper">
			<h2>Users and their orders</h2><br>
		</div>
		</section><?php
		$sql3="(SELECT user_id,COUNT(orderno) as No_of_orders FROM `orders` GROUP BY(user_id)) UNION (SELECT u.user_id,'0' from users u where user_id not in (SELECT user_id from orders))";
		$result3=mysqli_query($conn,$sql3);
		$resultCheck3 = mysqli_num_rows($result3);

		?>
				<br><center style="font-style: italic;font-size: 30px">
					<table width="500px" height="150px" border="2px" cellpadding="20px" cellspacing="5px" style="background-color: white;text-align: center;">
					<tr >
						<th>Userid</th>
						<th>No Of Orders</th>
					</tr>
			<?php 
				
			while($row3=$result3->fetch_assoc())
			{
				$userid=$row3['user_id'];
				$No_of_orders=$row3['No_of_orders'];

				echo"<tr>
							<td>$userid</td>
							<td>$No_of_orders</td>
					 </tr>";

			}
			?></table><?php
			echo "<br>Total No Of Users : $resultCheck3</center>";
		

	}

	?>
	<form class="signup-form" action="admin.php" method="POST">
		  <button type="submit" name="Back" >Back</button></form>
	<?php
?>

<?php
	include_once 'footer.php'; /*to include footer code here*/
?>
